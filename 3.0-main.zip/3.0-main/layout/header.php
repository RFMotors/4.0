<link rel="stylesheet" href="/css/headerFooter.css">
<header>
    <nav class="navbar">
        <div class="navdiv">
            <div class="logo">
                <a href="../HomePage.php">
                    <img src="../images/RFMotorsLOGO.png" alt="RF Motors"> RF Motors
                </a>
            </div>
            <ul>
                <li><a href="HomePage.php">Home</a></li>
                <li><a href="ContactPage.php">Contact</a></li>
                <button><a href="LoginPage.php">Login</a></button>
                <button><a href="LoginPage.php">Register</a></button>
            </ul>
        </div>
    </nav>
</header>