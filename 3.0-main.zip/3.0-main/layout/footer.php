<link rel="stylesheet" href="/css/headerFooter.css">
<footer>
    <p>&copy; 2025 RF Motors Rental Service. All rights reserved.</p>
    <p>Contact us: <a href="mailto:rfmotors@tudublin.ie">rfmotors@tudublin.ie</a></p>
</footer>
